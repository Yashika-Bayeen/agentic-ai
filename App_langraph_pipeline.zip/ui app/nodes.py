"""
Node implementations for the agentic code-generation graph.

Each node is a plain function: (ProjectState) -> partial ProjectState update.
They call an LLM (Claude, via langchain_anthropic) with the prompts defined
in prompts.py, and are defensive about parsing model output.
"""
from __future__ import annotations

import json
import os
import re
from typing import Any, Dict, List

from langchain_groq import ChatGroq

from prompts import (
    CODER_SYSTEM,
    CODER_USER_TEMPLATE,
    FIXER_SYSTEM,
    FIXER_USER_TEMPLATE,
    PLANNER_SYSTEM,
    PLANNER_USER_TEMPLATE,
    REVIEWER_SYSTEM,
    REVIEWER_USER_TEMPLATE,
)
from state import FileSpec, GeneratedFile, ProjectState

MODEL_NAME = os.environ.get("GROQ_MODEL", "llama-3.3-70b-versatile")
MAX_CONTEXT_CHARS_PER_FILE = 4000  # truncate existing files when feeding back as context


def _llm(temperature: float = 0.2) -> ChatGroq:
    return ChatGroq(model=MODEL_NAME, temperature=temperature, max_tokens=4096)


def _strip_fences(text: str) -> str:
    """Remove ```json / ``` fences if the model added them despite instructions."""
    text = text.strip()
    text = re.sub(r"^```[a-zA-Z]*\n", "", text)
    text = re.sub(r"\n```$", "", text)
    return text.strip()


def _parse_json(text: str) -> Dict[str, Any]:
    cleaned = _strip_fences(text)
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        # last-resort: grab the outermost {...} block
        match = re.search(r"\{.*\}", cleaned, re.DOTALL)
        if match:
            return json.loads(match.group(0))
        raise


def _plan_summary(plan: List[FileSpec]) -> str:
    lines = []
    for f in plan:
        deps = ", ".join(f.get("depends_on", [])) or "none"
        lines.append(f"- {f['path']}: {f['purpose']} (depends on: {deps})")
    return "\n".join(lines)


def _existing_files_summary(files_done: List[GeneratedFile]) -> str:
    if not files_done:
        return "(none yet)"
    chunks = []
    for f in files_done:
        content = f["content"]
        if len(content) > MAX_CONTEXT_CHARS_PER_FILE:
            content = content[:MAX_CONTEXT_CHARS_PER_FILE] + "\n...[truncated]..."
        chunks.append(f"--- {f['path']} ---\n{content}")
    return "\n\n".join(chunks)


# ---------------------------------------------------------------------------
# Nodes
# ---------------------------------------------------------------------------

def planner_node(state: ProjectState) -> Dict[str, Any]:
    llm = _llm(temperature=0.3)
    user_msg = PLANNER_USER_TEMPLATE.format(request=state["request"])
    resp = llm.invoke([
        ("system", PLANNER_SYSTEM),
        ("human", user_msg),
    ])
    data = _parse_json(resp.content)

    plan: List[FileSpec] = [
        {
            "path": f["path"],
            "purpose": f.get("purpose", ""),
            "depends_on": f.get("depends_on", []),
        }
        for f in data["files"]
    ]

    return {
        "project_name": data.get("project_name", state.get("project_name", "generated-project")),
        "tech_stack": data.get("tech_stack", ""),
        "plan": plan,
        "files_done": [],
        "pending_index": 0,
        "revision_count": 0,
        "log": [f"Planner produced {len(plan)} file(s): {[f['path'] for f in plan]}"],
    }


def coder_node(state: ProjectState) -> Dict[str, Any]:
    plan = state["plan"]
    idx = state["pending_index"]
    target = plan[idx]

    llm = _llm(temperature=0.2)
    user_msg = CODER_USER_TEMPLATE.format(
        project_name=state.get("project_name", ""),
        tech_stack=state.get("tech_stack", ""),
        plan_summary=_plan_summary(plan),
        existing_files_summary=_existing_files_summary(state.get("files_done", [])),
        target_path=target["path"],
        target_purpose=target["purpose"],
        target_depends_on=", ".join(target.get("depends_on", [])) or "none",
    )
    resp = llm.invoke([
        ("system", CODER_SYSTEM),
        ("human", user_msg),
    ])
    content = _strip_fences(resp.content)

    new_file: GeneratedFile = {"path": target["path"], "content": content}
    files_done = state.get("files_done", []) + [new_file]

    return {
        "files_done": files_done,
        "pending_index": idx + 1,
        "log": [f"Generated {target['path']} ({len(content)} chars)"],
    }


def reviewer_node(state: ProjectState) -> Dict[str, Any]:
    llm = _llm(temperature=0.0)
    all_files = "\n\n".join(
        f"--- {f['path']} ---\n{f['content']}" for f in state["files_done"]
    )
    user_msg = REVIEWER_USER_TEMPLATE.format(
        project_name=state.get("project_name", ""),
        tech_stack=state.get("tech_stack", ""),
        plan_summary=_plan_summary(state["plan"]),
        all_files_summary=all_files,
    )
    resp = llm.invoke([
        ("system", REVIEWER_SYSTEM),
        ("human", user_msg),
    ])
    data = _parse_json(resp.content)

    approved = bool(data.get("approved", False))
    files_to_fix = data.get("files_to_fix", []) if not approved else []

    return {
        "approved": approved,
        "review_feedback": data.get("feedback", ""),
        "files_to_fix": files_to_fix,
        "log": [f"Reviewer verdict: {'APPROVED' if approved else 'NEEDS FIXES -> ' + str(files_to_fix)}"],
    }


def fixer_node(state: ProjectState) -> Dict[str, Any]:
    llm = _llm(temperature=0.2)
    files_by_path = {f["path"]: f for f in state["files_done"]}
    all_files = "\n\n".join(
        f"--- {f['path']} ---\n{f['content']}" for f in state["files_done"]
    )

    updated = dict(files_by_path)
    for path in state.get("files_to_fix", []):
        if path not in files_by_path:
            continue
        user_msg = FIXER_USER_TEMPLATE.format(
            project_name=state.get("project_name", ""),
            tech_stack=state.get("tech_stack", ""),
            plan_summary=_plan_summary(state["plan"]),
            all_files_summary=all_files,
            feedback=state.get("review_feedback", ""),
            target_path=path,
        )
        resp = llm.invoke([
            ("system", FIXER_SYSTEM),
            ("human", user_msg),
        ])
        updated[path] = {"path": path, "content": _strip_fences(resp.content)}

    # preserve original plan order
    ordered = [updated[f["path"]] for f in state["files_done"]]

    return {
        "files_done": ordered,
        "revision_count": state.get("revision_count", 0) + 1,
        "log": [f"Fixer revised: {state.get('files_to_fix', [])}"],
    }


def writer_node(state: ProjectState) -> Dict[str, Any]:
    output_dir = state["output_dir"]
    written = []
    for f in state["files_done"]:
        full_path = os.path.join(output_dir, f["path"])
        os.makedirs(os.path.dirname(full_path) or ".", exist_ok=True)
        with open(full_path, "w", encoding="utf-8") as fh:
            fh.write(f["content"])
        written.append(full_path)

    return {
        "written_paths": written,
        "log": [f"Wrote {len(written)} file(s) to {output_dir}"],
    }


# ---------------------------------------------------------------------------
# Routing functions (conditional edges)
# ---------------------------------------------------------------------------

def route_after_coder(state: ProjectState) -> str:
    if state["pending_index"] < len(state["plan"]):
        return "coder"
    return "reviewer"


def route_after_reviewer(state: ProjectState) -> str:
    if state.get("approved"):
        return "writer"
    if state.get("revision_count", 0) >= state.get("max_revisions", 2):
        # give up trying to perfect it further; ship what we have
        return "writer"
    return "fixer"
