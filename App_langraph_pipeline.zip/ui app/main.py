#!/usr/bin/env python3
"""
CLI for the agentic LangGraph code-generation pipeline.

Example:
    export GROQ_API_KEY=gsk_...
    python main.py "A todo list web app with local storage persistence" -o ./todo_app
"""
from __future__ import annotations

import argparse
import os
import sys

from dotenv import load_dotenv

from pipeline import run_pipeline


def print_tree(root: str) -> None:
    for dirpath, _dirnames, filenames in os.walk(root):
        rel = os.path.relpath(dirpath, root)
        indent = "" if rel == "." else "  " * rel.count(os.sep) + "  "
        if rel != ".":
            print(f"{indent}{os.path.basename(dirpath)}/")
        for name in sorted(filenames):
            file_indent = "  " * (rel.count(os.sep) + 1) if rel != "." else "  "
            print(f"{file_indent}{name}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate a multi-file project with an agentic LangGraph pipeline.")
    parser.add_argument("request", help="Natural-language description of the software/website to build.")
    parser.add_argument("-o", "--output-dir", default="./generated_project", help="Directory to write generated files into.")
    parser.add_argument("--max-revisions", type=int, default=2, help="Max reviewer->fixer loop iterations before shipping as-is.")
    args = parser.parse_args()

    load_dotenv()
    if not os.environ.get("GROQ_API_KEY"):
        print("ERROR: GROQ_API_KEY is not set. Export it or put it in a .env file.", file=sys.stderr)
        sys.exit(1)

    print(f"Building project for request:\n  {args.request!r}\n")
    result = run_pipeline(args.request, output_dir=args.output_dir, max_revisions=args.max_revisions)

    print("=== PIPELINE LOG ===")
    for line in result["log"]:
        print(" -", line)

    print(f"\n=== PROJECT TREE ({args.output_dir}) ===")
    print_tree(args.output_dir)

    if not result.get("approved", False):
        print(f"\nNote: reviewer did not fully approve the project (feedback: {result.get('review_feedback')!r}). "
              f"Shipped best effort after {result.get('revision_count', 0)} revision(s).")


if __name__ == "__main__":
    main()
