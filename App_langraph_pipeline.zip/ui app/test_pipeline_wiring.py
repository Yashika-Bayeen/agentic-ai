"""
Sanity test for the graph's control flow (planner -> coder loop -> reviewer
-> fixer loop -> writer) using a scripted fake LLM, so it can run without
network access or a real ANTHROPIC_API_KEY. Run with: python test_pipeline_wiring.py
"""
import json
import os
import shutil
import tempfile
from unittest.mock import patch

import nodes

PLAN_JSON = json.dumps({
    "project_name": "demo-site",
    "tech_stack": "static HTML/CSS/JS",
    "files": [
        {"path": "index.html", "purpose": "main page", "depends_on": ["styles/main.css"]},
        {"path": "styles/main.css", "purpose": "styling", "depends_on": []},
    ],
})

REVIEW_REJECT = json.dumps({
    "approved": False,
    "feedback": "index.html references a script.js that was never generated.",
    "files_to_fix": ["index.html"],
})

REVIEW_APPROVE = json.dumps({"approved": True, "feedback": "Looks good.", "files_to_fix": []})

call_count = {"n": 0}


class FakeResponse:
    def __init__(self, content):
        self.content = content


class FakeLLM:
    """Stands in for ChatAnthropic; returns scripted responses based on system prompt."""

    def invoke(self, messages):
        system_prompt = messages[0][1]
        call_count["n"] += 1

        if system_prompt is nodes.PLANNER_SYSTEM:
            return FakeResponse(PLAN_JSON)
        if system_prompt is nodes.CODER_SYSTEM:
            # crude: figure out which file from the user message
            user_msg = messages[1][1]
            if "index.html" in user_msg.split("Path:")[-1]:
                return FakeResponse("<html><body>Hello</body></html>")
            return FakeResponse("body { margin: 0; }")
        if system_prompt is nodes.REVIEWER_SYSTEM:
            # reject once, then approve, to exercise the fixer loop
            return FakeResponse(REVIEW_REJECT if call_count["n"] < 5 else REVIEW_APPROVE)
        if system_prompt is nodes.FIXER_SYSTEM:
            return FakeResponse("<html><body>Hello (fixed)</body></html>")
        raise AssertionError(f"Unexpected system prompt: {system_prompt}")


def run():
    tmp_dir = tempfile.mkdtemp()
    try:
        with patch.object(nodes, "_llm", return_value=FakeLLM()):
            from pipeline import run_pipeline
            result = run_pipeline("A demo site", output_dir=tmp_dir, max_revisions=2)

        assert result["approved"] is True, "Expected reviewer to eventually approve"
        assert result["revision_count"] >= 1, "Expected at least one fix cycle"
        written = set(os.path.relpath(p, tmp_dir) for p in result["written_paths"])
        assert written == {"index.html", "styles/main.css"}, written

        with open(os.path.join(tmp_dir, "index.html")) as f:
            assert "fixed" in f.read()

        print("OK: planner -> coder loop -> reviewer -> fixer -> writer all wired correctly.")
        print("Log:")
        for line in result["log"]:
            print(" -", line)
    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)


if __name__ == "__main__":
    run()
