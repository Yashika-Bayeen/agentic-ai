# Agentic Codegen — LangGraph pipeline that builds multi-file projects

A small LangGraph pipeline that turns a natural-language request ("a todo app",
"a portfolio website with a contact form") into a working, multi-file
codebase on disk, using **Groq** (fast open-weight models like Llama 3.3) as
the LLM at every step.

## Architecture

```
                ┌──────────┐
                │ planner  │  designs the file list + tech stack
                └────┬─────┘
                     │
                     ▼
                ┌──────────┐
        ┌──────▶│  coder   │  writes ONE file per call, sees prior files for context
        │       └────┬─────┘
        │  loop until │
        │  all files  │ done
        └─────────────┤
                       ▼
                ┌──────────┐
          ┌────▶│ reviewer │  checks cross-file consistency, returns approve/reject
          │     └────┬─────┘
          │           │
          │   rejected│           approved (or max revisions hit)
          │           ▼                    │
          │     ┌──────────┐               ▼
          └─────│  fixer   │         ┌──────────┐
                └──────────┘         │  writer  │  writes files to disk
                                     └────┬─────┘
                                          ▼
                                         END
```

* **planner** — one LLM call. Produces a JSON plan: project name, tech stack,
  and a list of files with their purpose and dependencies.
* **coder** — one LLM call **per file**. Each call sees the full plan plus the
  content of every file generated so far, so imports/IDs/routes stay consistent.
  A conditional edge loops this node until every planned file is generated.
* **reviewer** — one LLM call. Reads the entire generated project and returns
  `{approved, feedback, files_to_fix}` as strict JSON.
* **fixer** — regenerates only the files the reviewer flagged, using its
  feedback as instructions. Loops back to the reviewer.
* **writer** — writes every generated file to `output_dir`, creating
  subdirectories as needed.

The reviewer/fixer loop is bounded by `max_revisions` (default 2) so the graph
always terminates even if the reviewer keeps finding things to flag.

## Files

| File | Purpose |
|---|---|
| `state.py` | `TypedDict` schema shared across all nodes (`ProjectState`) |
| `prompts.py` | System/user prompt templates for each agent |
| `nodes.py` | Node functions + JSON-parsing helpers + routing functions |
| `pipeline.py` | Builds the `StateGraph`, wires nodes/edges, `run_pipeline()` |
| `main.py` | CLI entry point |
| `test_pipeline_wiring.py` | Verifies control flow with a scripted fake LLM (no API key needed) |

## Setup

```bash
pip install -r requirements.txt
export GROQ_API_KEY=gsk_...
```

Get a free key at https://console.groq.com/keys.

## Usage

CLI:
```bash
python main.py "A single-page portfolio website with a hero section, an about section, and a contact form" -o ./portfolio_site
```

Python:
```python
from pipeline import run_pipeline

result = run_pipeline(
    "A Flask REST API for a todo list with SQLite persistence",
    output_dir="./todo_api",
    max_revisions=2,
)

print(result["log"])          # step-by-step trace
print(result["written_paths"]) # every file written to disk
```

## Verifying the wiring without an API key

`test_pipeline_wiring.py` monkey-patches the LLM call with a scripted fake
that deliberately rejects the review once (to exercise the fixer loop) and
then approves, so you can confirm the graph's control flow is correct before
spending any real API calls:

```bash
python test_pipeline_wiring.py
```

## Customizing

- **Model**: set the `GROQ_MODEL` env var (defaults to `llama-3.3-70b-versatile`).
  Other options on Groq include `llama-3.1-8b-instant` (cheaper/faster, weaker
  at consistency across files) and `mixtral-8x7b-32768`/`qwen`-family models
  as they become available — check `console.groq.com` for the current list.
- **Stricter review**: raise `max_revisions`, or tighten `REVIEWER_SYSTEM` in
  `prompts.py` to check for specific things (accessibility, security, tests).
- **Different project types**: the planner has no hard-coded tech stack — it's
  driven entirely by the request text, so "React app", "Python CLI tool",
  "static website", etc. all work without code changes.
- **Parallel file generation**: the current `coder` loop is sequential so each
  file can see previously generated files for consistency. For independent
  files (e.g. static assets) you could fan out with LangGraph's `Send` API to
  generate several files concurrently, then merge before the reviewer.
