// Get the todo list items element and the add todo form element
const todoListItems = document.getElementById('todo-list-items');
const addTodoForm = document.getElementById('add-todo-form');
const todoInput = document.getElementById('todo-input');

// Initialize an empty array to store the todo items
let todoItems = [];

// Load the todo items from local storage
function loadTodoItems() {
    const storedTodoItems = localStorage.getItem('todoItems');
    if (storedTodoItems) {
        todoItems = JSON.parse(storedTodoItems);
        renderTodoList();
    }
}

// Render the todo list
function renderTodoList() {
    todoListItems.innerHTML = '';
    todoItems.forEach((item, index) => {
        const listItem = document.createElement('li');
        listItem.textContent = item;
        listItem.addEventListener('click', () => {
            // Remove the todo item from the array and local storage
            todoItems.splice(index, 1);
            localStorage.setItem('todoItems', JSON.stringify(todoItems));
            renderTodoList();
        });
        todoListItems.appendChild(listItem);
    });
}

// Add event listener to the add todo form
addTodoForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const newTodoItem = todoInput.value.trim();
    if (newTodoItem) {
        // Add the new todo item to the array and local storage
        todoItems.push(newTodoItem);
        localStorage.setItem('todoItems', JSON.stringify(todoItems));
        renderTodoList();
        todoInput.value = '';
    }
});

// Load the todo items from local storage when the page loads
loadTodoItems();