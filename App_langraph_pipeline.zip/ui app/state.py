"""
Shared state definition for the LangGraph agentic code-generation pipeline.
"""
from __future__ import annotations

import operator
from typing import Dict, List, Optional, TypedDict

from typing_extensions import Annotated


class FileSpec(TypedDict):
    """One planned file in the project."""
    path: str          # relative path, e.g. "src/index.html"
    purpose: str       # one-line description of what the file does
    depends_on: List[str]  # other planned paths this file relies on


class GeneratedFile(TypedDict):
    path: str
    content: str


class ProjectState(TypedDict, total=False):
    # ---- inputs ----
    request: str            # the user's natural-language request
    project_name: str
    tech_stack: str          # e.g. "static HTML/CSS/JS" or "Python Flask"
    output_dir: str          # where files get written on disk
    max_revisions: int

    # ---- working memory ----
    plan: List[FileSpec]
    files_done: List[GeneratedFile]
    pending_index: int        # index into `plan` of the next file to generate

    # ---- review loop ----
    review_feedback: str
    files_to_fix: List[str]
    approved: bool
    revision_count: int

    # ---- output ----
    written_paths: List[str]

    # append-only trace of what happened, useful for debugging/UI
    log: Annotated[List[str], operator.add]
