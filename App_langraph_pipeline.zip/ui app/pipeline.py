"""
Assembles the LangGraph pipeline:

    planner -> coder -(loop until all files done)-> reviewer
             -> [needs fixes] -> fixer -> reviewer
             -> [approved OR max revisions hit] -> writer -> END

Usage:
    from pipeline import build_graph, run_pipeline
    result = run_pipeline("A single-page portfolio website with a contact form",
                           output_dir="./my_site")
"""
from __future__ import annotations

from typing import Any, Dict

from langgraph.graph import END, StateGraph

from nodes import (
    coder_node,
    fixer_node,
    planner_node,
    reviewer_node,
    route_after_coder,
    route_after_reviewer,
    writer_node,
)
from state import ProjectState


def build_graph():
    graph = StateGraph(ProjectState)

    graph.add_node("planner", planner_node)
    graph.add_node("coder", coder_node)
    graph.add_node("reviewer", reviewer_node)
    graph.add_node("fixer", fixer_node)
    graph.add_node("writer", writer_node)

    graph.set_entry_point("planner")
    graph.add_edge("planner", "coder")

    graph.add_conditional_edges(
        "coder",
        route_after_coder,
        {"coder": "coder", "reviewer": "reviewer"},
    )
    graph.add_conditional_edges(
        "reviewer",
        route_after_reviewer,
        {"fixer": "fixer", "writer": "writer"},
    )
    graph.add_edge("fixer", "reviewer")
    graph.add_edge("writer", END)

    return graph.compile()


def run_pipeline(
    request: str,
    output_dir: str = "./generated_project",
    max_revisions: int = 2,
) -> Dict[str, Any]:
    """Convenience entry point: runs the full graph and returns the final state."""
    app = build_graph()
    initial_state: ProjectState = {
        "request": request,
        "output_dir": output_dir,
        "max_revisions": max_revisions,
        "log": [],
    }
    final_state = app.invoke(initial_state, config={"recursion_limit": 100})
    return final_state


if __name__ == "__main__":
    import sys

    req = sys.argv[1] if len(sys.argv) > 1 else (
        "A simple static personal portfolio website with a home page, "
        "an about section, and a contact form."
    )
    out_dir = sys.argv[2] if len(sys.argv) > 2 else "./generated_project"

    result = run_pipeline(req, output_dir=out_dir)

    print("\n=== LOG ===")
    for line in result["log"]:
        print("-", line)

    print(f"\n=== FILES WRITTEN TO {out_dir} ===")
    for p in result.get("written_paths", []):
        print("-", p)
