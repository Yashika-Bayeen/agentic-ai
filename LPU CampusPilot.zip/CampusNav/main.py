"""
CampusPilot — Smart Campus Navigation & Event Logistics Agent (Groq-powered).

Run:  python -m uvicorn main:app --reload
Then open http://127.0.0.1:8000
"""

import os
from contextlib import asynccontextmanager
from pathlib import Path

from dotenv import load_dotenv
from fastapi import FastAPI
from fastapi.responses import FileResponse, JSONResponse
from fastapi.concurrency import run_in_threadpool
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from datetime import datetime

load_dotenv(override=True)

import campus_data as cd
import simulator
import tools
import agent


@asynccontextmanager
async def lifespan(app: FastAPI):
    simulator.start()
    cd.add_notification("info", "CampusPilot online",
                        "Live schedule monitoring started. Disruptions will appear here in real time.")
    yield
    simulator.stop()


app = FastAPI(title="CampusPilot", lifespan=lifespan)
STATIC_DIR = Path(__file__).parent / "static"

# Serve static files (lpu-paths.geojson, etc.)
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


class ChatRequest(BaseModel):
    session_id: str = "default"
    message: str


class UMSLoginRequest(BaseModel):
    reg_id: str
    password: str


# Simulated UMS student profiles for demo
UMS_PROFILES = {
    "12215678": {
        "name": "Aarav Sharma", "password": "aarav123",
        "programme": "B.Tech CSE (Sem 6)", "hostel": "Block 57",
        "hostel_node": "Block 57",
        "schedule": [
            {"id":"C1","time":"09:00","end":"09:50","course":"CSE322 Formal Languages & Automata","room":"32-304","location":"Block 32","status":"scheduled"},
            {"id":"C2","time":"10:00","end":"10:50","course":"CSE325 Operating Systems Lab","room":"55-106","location":"Block 55","status":"scheduled"},
            {"id":"C3","time":"12:00","end":"12:50","course":"MTH401 Discrete Mathematics","room":"26-201","location":"Block 26","status":"scheduled"},
            {"id":"C4","time":"14:00","end":"15:30","course":"One World Volunteer Briefing","room":"Unipolis Hall A","location":"Block 27","status":"scheduled"},
            {"id":"C5","time":"16:00","end":"16:50","course":"PEA305 Analytical Skills","room":"34-403","location":"Block 34","status":"scheduled"},
        ]
    },
    "12219001": {
        "name": "Priya Verma", "password": "priya123",
        "programme": "B.Tech ECE (Sem 4)", "hostel": "Girls Hostel",
        "hostel_node": "Girls Hostel",
        "schedule": [
            {"id":"C1","time":"08:00","end":"08:50","course":"ECE201 Signals & Systems","room":"25-102","location":"Block 25","status":"scheduled"},
            {"id":"C2","time":"10:00","end":"10:50","course":"ECE210 Digital Electronics Lab","room":"38-Lab2","location":"Block 38","status":"scheduled"},
            {"id":"C3","time":"12:00","end":"12:50","course":"MTH301 Linear Algebra","room":"27-201","location":"Block 27","status":"scheduled"},
            {"id":"C4","time":"14:00","end":"14:50","course":"PHY202 Electromagnetic Theory","room":"30-301","location":"Block 30","status":"scheduled"},
            {"id":"C5","time":"16:00","end":"16:50","course":"HSS201 Professional Ethics","room":"13-201","location":"Block 13","status":"scheduled"},
        ]
    },
    "12218045": {
        "name": "Rahul Patel", "password": "rahul123",
        "programme": "B.Tech ME (Sem 5)", "hostel": "Block 58",
        "hostel_node": "Block 58",
        "schedule": [
            {"id":"C1","time":"09:00","end":"09:50","course":"ME301 Thermodynamics II","room":"34-101","location":"Block 34","status":"scheduled"},
            {"id":"C2","time":"11:00","end":"11:50","course":"ME310 Machine Design","room":"38-201","location":"Block 38","status":"scheduled"},
            {"id":"C3","time":"13:00","end":"13:50","course":"ME315 Fluid Mechanics Lab","room":"38-Lab3","location":"Block 38","status":"scheduled"},
            {"id":"C4","time":"15:00","end":"15:50","course":"MTH303 Numerical Methods","room":"32-105","location":"Block 32","status":"scheduled"},
        ]
    },
    "12217890": {
        "name": "Sneha Gupta", "password": "sneha123",
        "programme": "BBA (Sem 3)", "hostel": "Girls Hostel",
        "hostel_node": "Girls Hostel",
        "schedule": [
            {"id":"C1","time":"09:00","end":"09:50","course":"BBA201 Marketing Management","room":"14-201","location":"Block 14","status":"scheduled"},
            {"id":"C2","time":"10:00","end":"10:50","course":"BBA205 Financial Accounting","room":"14-301","location":"Block 14","status":"scheduled"},
            {"id":"C3","time":"12:00","end":"12:50","course":"BBA210 Business Law","room":"MSB-102","location":"Mittal School of Business","status":"scheduled"},
            {"id":"C4","time":"14:00","end":"14:50","course":"HSS101 Communication Skills","room":"13-301","location":"Block 13","status":"scheduled"},
        ]
    },
    "12216543": {
        "name": "Karan Singh", "password": "karan123",
        "programme": "B.Tech CSE-AI (Sem 4)", "hostel": "Block 56",
        "hostel_node": "Block 56",
        "schedule": [
            {"id":"C1","time":"08:00","end":"08:50","course":"CSE210 Data Structures","room":"32-201","location":"Block 32","status":"scheduled"},
            {"id":"C2","time":"10:00","end":"10:50","course":"CSE215 DBMS Lab","room":"55-201","location":"Block 55","status":"scheduled"},
            {"id":"C3","time":"12:00","end":"12:50","course":"MTH202 Probability & Statistics","room":"26-101","location":"Block 26","status":"scheduled"},
            {"id":"C4","time":"14:00","end":"14:50","course":"AI201 Introduction to AI","room":"55-301","location":"Block 55","status":"scheduled"},
            {"id":"C5","time":"16:00","end":"16:50","course":"CSE220 Computer Networks","room":"32-401","location":"Block 32","status":"scheduled"},
        ]
    },
    "12220101": {
        "name": "Ananya Reddy", "password": "ananya123",
        "programme": "B.Tech CSE (Sem 2)", "hostel": "Girls Hostel",
        "hostel_node": "Girls Hostel",
        "schedule": [
            {"id":"C1","time":"09:00","end":"09:50","course":"CSE101 Programming in C","room":"25-101","location":"Block 25","status":"scheduled"},
            {"id":"C2","time":"11:00","end":"11:50","course":"MTH101 Calculus","room":"26-301","location":"Block 26","status":"scheduled"},
            {"id":"C3","time":"13:00","end":"13:50","course":"PHY101 Engineering Physics","room":"27-101","location":"Block 27","status":"scheduled"},
            {"id":"C4","time":"15:00","end":"15:50","course":"ENG101 Technical English","room":"13-101","location":"Block 13","status":"scheduled"},
        ]
    },
}


@app.get("/")
async def index():
    return FileResponse(STATIC_DIR / "index.html")


@app.post("/api/chat")
async def api_chat(req: ChatRequest):
    text = req.message.strip()
    if not text:
        return JSONResponse({"error": "Empty message"}, status_code=400)
    try:
        # Groq SDK is synchronous — keep the event loop free
        result = await run_in_threadpool(agent.chat, req.session_id, text)
        return result
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)


@app.post("/api/reset")
async def api_reset(req: ChatRequest):
    agent.reset_session(req.session_id)
    return {"status": "reset"}


@app.post("/api/ums-login")
async def api_ums_login(req: UMSLoginRequest):
    """Simulated UMS credential verification."""
    rid = req.reg_id.strip()
    pwd = req.password.strip()
    if not rid or not pwd:
        return JSONResponse({"error": "Registration ID and password are required."}, status_code=400)
    profile = UMS_PROFILES.get(rid)
    if not profile:
        return JSONResponse({"error": "Invalid Registration ID. Try: 12215678, 12219001, 12218045, 12217890, 12216543, 12220101"}, status_code=401)
    if profile["password"] != pwd:
        return JSONResponse({"error": "Incorrect password. Hint: use the first name in lowercase + 123"}, status_code=401)
    # Return student info + schedule (strip password from response)
    now = datetime.now().strftime("%H:%M")
    return {
        "status": "success",
        "student": {
            "name": profile["name"],
            "reg_no": rid,
            "programme": profile["programme"],
            "hostel": profile["hostel"],
            "hostel_node": profile["hostel_node"],
        },
        "schedule": profile["schedule"],
        "current_time": now,
    }


@app.get("/api/state")
async def api_state():
    """Everything the dashboard polls: schedule, alerts, events, crowd, last route."""
    with cd.STATE_LOCK:
        return {
            "student": cd.STUDENT,
            "schedule": tools.get_student_schedule()["classes"],
            "notifications": cd.NOTIFICATIONS[:12],
            "events": tools.get_campus_events()["events"],
            "crowd": dict(cd.CROWD),
            "last_route": dict(cd.LAST_ROUTE),
        }


@app.get("/api/map")
async def api_map():
    """Static map geometry (fetched once by the frontend)."""
    return {
        "locations": {k: {"name": v["name"], "x": v["x"], "y": v["y"]}
                      for k, v in cd.LOCATIONS.items()},
        "edges": [{"a": a, "b": b, "minutes": w} for a, b, w in cd.EDGES],
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=int(os.environ.get("PORT", 8000)))
