"""
Live-campus disruption simulator.

A background thread that periodically injects realistic disruptions:
  - a class room / block change
  - a class postponement
  - a crowd surge at a location
  - a fest event venue change

Each disruption updates shared state and pushes a notification that already
contains a deterministic replan (new fastest route + timings) computed with
the same Dijkstra routing the agent uses — so the student is notified and
replanned even before they ask the agent anything.
"""

import random
import threading
import time
from datetime import datetime, timedelta

import campus_data as cd
from tools import dijkstra

INTERVAL_RANGE = (35, 65)  # seconds between disruptions

ALT_ROOMS = {
    "block_32": ["32-201", "32-405", "32-310"],
    "block_34": ["34-110", "34-305", "34-412"],
    "block_38": ["38-002", "38-214"],
    "block_55": ["55-201", "56-105", "57-302"],
    "block_25": ["25-101", "26-306", "27-204"],
    "block_13": ["13-Seminar Hall"],
}


def _upcoming_classes():
    now = datetime.now().strftime("%H:%M")
    return [c for c in cd.SCHEDULE if c["time"] >= now and c["status"] != "cancelled"]


def _previous_location(target):
    """Where the student is expected to be right before `target` class."""
    prev = cd.STUDENT["hostel"]
    for c in cd.SCHEDULE:
        if c["id"] == target["id"]:
            break
        prev = c["location"]
    return prev


def _route_text(origin, destination):
    path, minutes = dijkstra(origin, destination)
    if not path or len(path) < 2:
        return "You are already at the venue."
    steps = " -> ".join(cd.location_name(p) for p in path)
    return f"Fastest route ({minutes} min walk): {steps}."


def _disrupt_room_change():
    with cd.STATE_LOCK:
        candidates = _upcoming_classes()
        if not candidates:
            return
        cls = random.choice(candidates)
        new_block = random.choice([b for b in ALT_ROOMS if b != cls["location"]])
        old = f"{cls['room']} ({cd.location_name(cls['location'])})"
        cls["location"] = new_block
        cls["room"] = random.choice(ALT_ROOMS[new_block])
        cls["status"] = "room changed"
        origin = _previous_location(cls)
        body = (f"UMS update: {cls['course']} at {cls['time']} moved from {old} to "
                f"{cls['room']} ({cd.location_name(new_block)}). "
                + _route_text(origin, new_block))
    cd.add_notification("room_change", "Room change (UMS)", body)


def _disrupt_postponement():
    with cd.STATE_LOCK:
        candidates = _upcoming_classes()
        if not candidates:
            return
        cls = random.choice(candidates)
        delay = random.choice([30, 45, 60])
        fmt = "%H:%M"
        start = datetime.strptime(cls["time"], fmt) + timedelta(minutes=delay)
        end = datetime.strptime(cls["end"], fmt) + timedelta(minutes=delay)
        cls["time"], cls["end"] = start.strftime(fmt), end.strftime(fmt)
        cls["status"] = f"postponed +{delay} min"
        body = (f"UMS update: {cls['course']} postponed by {delay} minutes. "
                f"New slot: {cls['time']}–{cls['end']} in {cls['room']} "
                f"({cd.location_name(cls['location'])}). Free window opened — "
                f"ask CampusPilot what to do with it.")
        cd.SCHEDULE.sort(key=lambda c: c["time"])
    cd.add_notification("postponed", "Class postponed", body)


def _disrupt_crowd_surge():
    with cd.STATE_LOCK:
        loc = random.choice(list(cd.CROWD))
        cd.CROWD[loc] = random.randint(78, 98)
        # let other spots cool down a bit
        for k in cd.CROWD:
            if k != loc:
                cd.CROWD[k] = max(10, cd.CROWD[k] + random.randint(-12, 8))
        name = cd.location_name(loc)
        pct = cd.CROWD[loc]
    cd.add_notification("crowd", "Crowd surge",
                        f"Heavy crowd at {name} ({pct}% capacity) — Spectra/One World footfall. "
                        f"Routes through this area will be slower; ask for a detour if passing by.")


def _disrupt_event_venue():
    with cd.STATE_LOCK:
        ev = random.choice(cd.EVENTS)
        new_venue = random.choice([l for l in ("unipolis", "sdma", "sports", "block_55", "food_court")
                                   if l != ev["venue"]])
        old_name = cd.location_name(ev["venue"])
        ev["venue"] = new_venue
        body = (f"{ev['fest']} update: '{ev['name']}' shifted from {old_name} to "
                f"{cd.location_name(new_venue)} (starts {ev['time']}). "
                + _route_text(cd.STUDENT["hostel"], new_venue))
    cd.add_notification("event", "Event venue changed", body)


DISRUPTIONS = [
    (_disrupt_room_change, 0.30),
    (_disrupt_postponement, 0.20),
    (_disrupt_crowd_surge, 0.35),
    (_disrupt_event_venue, 0.15),
]


def _loop(stop_event: threading.Event):
    # small initial delay so the UI loads before the first alert
    time.sleep(12)
    while not stop_event.is_set():
        fn = random.choices([d[0] for d in DISRUPTIONS],
                            weights=[d[1] for d in DISRUPTIONS])[0]
        try:
            fn()
        except Exception:
            pass  # a bad draw must never kill the simulator
        stop_event.wait(random.randint(*INTERVAL_RANGE))


_stop = threading.Event()


def start():
    t = threading.Thread(target=_loop, args=(_stop,), daemon=True, name="campus-simulator")
    t.start()
    return t


def stop():
    _stop.set()
