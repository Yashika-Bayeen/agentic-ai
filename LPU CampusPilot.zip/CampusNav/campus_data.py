"""
LPU campus knowledge base + live mutable state for the Smart Campus Agent.

Modelled on Lovely Professional University's main campus (Jalandhar-Delhi
G.T. Road, Phagwara): real landmarks like Uni-Mall, Block 13 Central Library,
Baldev Raj Mittal Unipolis and the Shanti Devi Mittal Auditorium. Walking
times are estimates; swap in real UMS / sensor feeds to go live.

Everything mutated at runtime by the disruption simulator lives behind
STATE_LOCK.
"""

import threading
from datetime import datetime

STATE_LOCK = threading.RLock()

# ---------------------------------------------------------------------------
# Campus map: nodes (locations) and weighted edges (walking minutes)
# ---------------------------------------------------------------------------

LOCATIONS = {
    "gate1":      {"name": "Main Gate (Gate 1, G.T. Road)",             "x": 10, "y": 14},
    "uni_mall":   {"name": "Uni-Mall & Shopping Street",                "x": 24, "y": 20},
    "block_1":    {"name": "Block 1 - Admin & Admissions",              "x": 12, "y": 32},
    "block_13":   {"name": "Block 13 - Central Library",                "x": 30, "y": 36},
    "block_25":   {"name": "Blocks 25-27 - Lecture Theatres",           "x": 46, "y": 22},
    "block_32":   {"name": "Block 32 - School of CSE",                  "x": 56, "y": 36},
    "block_34":   {"name": "Block 34 - Engineering Block",              "x": 68, "y": 28},
    "block_38":   {"name": "Block 38 - Workshops & Mech Labs",          "x": 80, "y": 22},
    "block_55":   {"name": "Blocks 55-57 - New Academic Zone",          "x": 72, "y": 48},
    "unipolis":   {"name": "Baldev Raj Mittal Unipolis",                "x": 44, "y": 52},
    "sdma":       {"name": "Shanti Devi Mittal Auditorium",             "x": 58, "y": 58},
    "food_court": {"name": "Central Food Court",                        "x": 34, "y": 62},
    "hospital":   {"name": "Uni-Hospital",                              "x": 22, "y": 50},
    "sports":     {"name": "Sports Stadium & Grounds",                  "x": 62, "y": 76},
    "bh":         {"name": "Boys Hostel Zone (BH-1 to BH-7)",           "x": 86, "y": 62},
    "gh":         {"name": "Girls Hostel Zone (GH-1 to GH-6)",          "x": 16, "y": 74},
}

# Undirected edges: (a, b, walking_minutes)
EDGES = [
    ("gate1", "uni_mall", 3),
    ("gate1", "block_1", 3),
    ("block_1", "block_13", 4),
    ("uni_mall", "block_13", 4),
    ("uni_mall", "block_25", 6),
    ("block_13", "unipolis", 5),
    ("block_13", "hospital", 4),
    ("block_25", "block_32", 4),
    ("block_25", "block_34", 6),
    ("block_32", "block_34", 4),
    ("block_32", "unipolis", 5),
    ("block_32", "block_55", 5),
    ("block_34", "block_38", 3),
    ("block_34", "block_55", 4),
    ("block_38", "bh", 6),
    ("block_55", "sdma", 4),
    ("block_55", "bh", 5),
    ("unipolis", "sdma", 3),
    ("unipolis", "food_court", 3),
    ("sdma", "sports", 5),
    ("food_court", "hospital", 4),
    ("food_court", "gh", 5),
    ("food_court", "sports", 7),
    ("gh", "hospital", 6),
    ("sports", "bh", 5),
]

GRAPH = {loc: [] for loc in LOCATIONS}
for a, b, w in EDGES:
    GRAPH[a].append((b, w))
    GRAPH[b].append((a, w))

# ---------------------------------------------------------------------------
# Verto profile + today's timetable (mutable: rooms/times change at runtime)
# ---------------------------------------------------------------------------

STUDENT = {
    "name": "Aarav Sharma",
    "reg_no": "12215678",
    "programme": "B.Tech CSE (Sem 6)",
    "hostel": "bh",
}

SCHEDULE = [
    {"id": "C1", "time": "09:00", "end": "09:50", "course": "CSE322 Formal Languages & Automata",
     "room": "32-304", "location": "block_32", "status": "scheduled"},
    {"id": "C2", "time": "10:00", "end": "10:50", "course": "CSE325 Operating Systems Lab",
     "room": "55-106", "location": "block_55", "status": "scheduled"},
    {"id": "C3", "time": "12:00", "end": "12:50", "course": "MTH401 Discrete Mathematics",
     "room": "26-201", "location": "block_25", "status": "scheduled"},
    {"id": "C4", "time": "14:00", "end": "15:30", "course": "One World Volunteer Briefing",
     "room": "Unipolis Hall A", "location": "unipolis", "status": "scheduled"},
    {"id": "C5", "time": "16:00", "end": "16:50", "course": "PEA305 Analytical Skills",
     "room": "34-403", "location": "block_34", "status": "scheduled"},
]

# ---------------------------------------------------------------------------
# Fest events (Spectra + One World 2026) — mutable: venues shift, seats fill
# ---------------------------------------------------------------------------

EVENTS = [
    {"id": "E1", "name": "CodeStorm 24h Hackathon", "fest": "Spectra", "venue": "block_55",
     "time": "10:00", "capacity": 200, "registered": 143, "student_registered": False},
    {"id": "E2", "name": "RoboWars Arena", "fest": "Spectra", "venue": "block_38",
     "time": "13:00", "capacity": 150, "registered": 150, "student_registered": False},
    {"id": "E3", "name": "Battle of Bands", "fest": "Spectra", "venue": "sdma",
     "time": "17:00", "capacity": 800, "registered": 512, "student_registered": False},
    {"id": "E4", "name": "Global Food Carnival", "fest": "One World", "venue": "food_court",
     "time": "12:00", "capacity": 1000, "registered": 640, "student_registered": False},
    {"id": "E5", "name": "Cultural Parade of Nations", "fest": "One World", "venue": "sports",
     "time": "15:00", "capacity": 2000, "registered": 1180, "student_registered": False},
    {"id": "E6", "name": "DJ Night ft. Guest Artist", "fest": "Spectra", "venue": "sports",
     "time": "19:30", "capacity": 3000, "registered": 2110, "student_registered": False},
]

# ---------------------------------------------------------------------------
# Live crowd levels (0–100 %) per location — mutated by the simulator
# ---------------------------------------------------------------------------

CROWD = {
    "gate1": 40, "uni_mall": 60, "block_1": 30, "block_13": 45,
    "block_25": 35, "block_32": 48, "block_34": 36, "block_38": 40,
    "block_55": 42, "unipolis": 65, "sdma": 50, "food_court": 72,
    "hospital": 20, "sports": 25, "bh": 15, "gh": 15,
}

# ---------------------------------------------------------------------------
# Notification feed + last route computed (for the map highlight)
# ---------------------------------------------------------------------------

NOTIFICATIONS = []            # newest first: {id, time, type, title, body}
LAST_ROUTE = {"path": [], "minutes": 0}
_notif_counter = 0


def add_notification(ntype: str, title: str, body: str):
    global _notif_counter
    with STATE_LOCK:
        _notif_counter += 1
        NOTIFICATIONS.insert(0, {
            "id": _notif_counter,
            "time": datetime.now().strftime("%H:%M:%S"),
            "type": ntype,
            "title": title,
            "body": body,
        })
        del NOTIFICATIONS[50:]  # keep the feed bounded


def location_name(loc_id: str) -> str:
    return LOCATIONS.get(loc_id, {}).get("name", loc_id)


# ---------------------------------------------------------------------------
# Full campus building directory (all blocks with GPS coords & descriptions)
# Used by the AI chat agent to answer "where is Block X?" questions
# ---------------------------------------------------------------------------

BUILDINGS = {
    "Block 1":   {"lat": 31.258495, "lng": 75.708869, "desc": "Admin & Admissions Office, North Campus"},
    "Block 2A":  {"lat": 31.258385, "lng": 75.708160, "desc": "Academic block near Food Court LPU"},
    "Block 2B":  {"lat": 31.258115, "lng": 75.707828, "desc": "Academic block near Uni Hospital"},
    "Block 3A":  {"lat": 31.257908, "lng": 75.706835, "desc": "Academic block adjacent to Uni Hospital"},
    "Block 3B":  {"lat": 31.257620, "lng": 75.707361, "desc": "Academic block near Block 3A"},
    "Block 6":   {"lat": 31.256776, "lng": 75.707415, "desc": "Academic block, Upper Campus"},
    "Block 7":   {"lat": 31.256844, "lng": 75.706868, "desc": "Academic block, Upper Campus"},
    "Block 8":   {"lat": 31.256542, "lng": 75.706728, "desc": "Academic block, Upper Campus"},
    "Block 9":   {"lat": 31.256940, "lng": 75.705602, "desc": "Academic block near Block 12"},
    "Block 10":  {"lat": 31.256730, "lng": 75.704797, "desc": "Academic block, West Upper Campus"},
    "Block 11":  {"lat": 31.256179, "lng": 75.704196, "desc": "Academic block, westernmost upper campus"},
    "Block 12":  {"lat": 31.256477, "lng": 75.705548, "desc": "Academic block near Block 9"},
    "Block 13":  {"lat": 31.255079, "lng": 75.706047, "desc": "Central Library & academic block"},
    "Block 14":  {"lat": 31.254497, "lng": 75.705537, "desc": "Academic block near Student Welfare"},
    "Block 15A": {"lat": 31.255804, "lng": 75.705425, "desc": "Academic block, mid-campus"},
    "Block 15B": {"lat": 31.255735, "lng": 75.704244, "desc": "Academic block, mid-campus"},
    "Block 18":  {"lat": 31.255253, "lng": 75.703375, "desc": "Academic block, west of Helipad"},
    "Block 20":  {"lat": 31.254744, "lng": 75.701369, "desc": "Academic block near Law Gate"},
    "Block 20A": {"lat": 31.255097, "lng": 75.701455, "desc": "Academic block near Law Gate"},
    "Block 20B": {"lat": 31.254689, "lng": 75.701337, "desc": "Academic block near Block 20"},
    "Block 20C": {"lat": 31.254707, "lng": 75.700967, "desc": "Academic block near Block 20"},
    "Block 21A": {"lat": 31.253607, "lng": 75.701144, "desc": "Academic block, central-west campus"},
    "Block 21B": {"lat": 31.253657, "lng": 75.700656, "desc": "Academic block near 21A"},
    "Block 25":  {"lat": 31.252745, "lng": 75.702410, "desc": "Lecture Theatres zone, Central Academic"},
    "Block 26":  {"lat": 31.252745, "lng": 75.702871, "desc": "Lecture Theatres zone near Block 25"},
    "Block 27":  {"lat": 31.252718, "lng": 75.703268, "desc": "Lecture zone / Unipolis area"},
    "Block 28":  {"lat": 31.252672, "lng": 75.703762, "desc": "Academic block, central cluster"},
    "Block 29":  {"lat": 31.252672, "lng": 75.704137, "desc": "Academic block, central cluster"},
    "Block 30":  {"lat": 31.252644, "lng": 75.704566, "desc": "Academic block, central cluster"},
    "Block 31":  {"lat": 31.252626, "lng": 75.704867, "desc": "Academic block, east of central cluster"},
    "Block 32":  {"lat": 31.252208, "lng": 75.704786, "desc": "School of CSE (Computer Science & Engineering)"},
    "Block 33":  {"lat": 31.251846, "lng": 75.704711, "desc": "Academic block near Block 32"},
    "Block 34":  {"lat": 31.251502, "lng": 75.704684, "desc": "Engineering Block, south of Block 32"},
    "Block 35":  {"lat": 31.252122, "lng": 75.704062, "desc": "Academic block, inner central cluster"},
    "Block 36":  {"lat": 31.251627, "lng": 75.704116, "desc": "Academic block, inner central cluster"},
    "Block 37":  {"lat": 31.251837, "lng": 75.703654, "desc": "Academic block near Block 38"},
    "Block 38":  {"lat": 31.252140, "lng": 75.703182, "desc": "Workshops & Mechanical Labs"},
    "Block 39":  {"lat": 31.251016, "lng": 75.705677, "desc": "Academic block, east-south campus"},
    "Block 41A": {"lat": 31.251883, "lng": 75.701970, "desc": "Academic block, south-west campus"},
    "Block 41B": {"lat": 31.251764, "lng": 75.701562, "desc": "Academic block near 41A"},
    "Block 41C": {"lat": 31.251883, "lng": 75.701315, "desc": "Academic block near 41A"},
    "Block 41D": {"lat": 31.251837, "lng": 75.700961, "desc": "Academic block near 41A"},
    "Block 45":  {"lat": 31.251296, "lng": 75.699964, "desc": "Academic block, south-west campus"},
    "Block 47":  {"lat": 31.250718, "lng": 75.701584, "desc": "Academic block, south campus"},
    "Block 48":  {"lat": 31.249710, "lng": 75.700854, "desc": "Academic block, far-south campus"},
    "Block 49":  {"lat": 31.249637, "lng": 75.700125, "desc": "Academic block, far-south campus"},
    "Block 50":  {"lat": 31.249563, "lng": 75.699427, "desc": "Academic block, far-south campus"},
    "Block 51A": {"lat": 31.248747, "lng": 75.700049, "desc": "Academic block, deep south campus"},
    "Block 51B": {"lat": 31.248646, "lng": 75.699191, "desc": "Academic block near 51A"},
    "Block 53":  {"lat": 31.248674, "lng": 75.703601, "desc": "Academic block, south campus near hostels"},
    "Block 54":  {"lat": 31.247858, "lng": 75.703708, "desc": "Academic block, south campus hostel area"},
    "Block 55":  {"lat": 31.247078, "lng": 75.703504, "desc": "New Academic Zone (Blocks 55-57)"},
    "Block 56":  {"lat": 31.246767, "lng": 75.703783, "desc": "New Academic Zone hostel area"},
    "Block 57":  {"lat": 31.246244, "lng": 75.703590, "desc": "Boys Hostel Zone (BH)"},
    "Block 58":  {"lat": 31.245914, "lng": 75.703837, "desc": "Boys Hostel Zone (BH)"},
    # Landmarks
    "Main Gate":              {"lat": 31.260631, "lng": 75.706723, "desc": "Main entrance on G.T. Road (Gate 1)"},
    "Law Gate":               {"lat": 31.255019, "lng": 75.700344, "desc": "West entrance near Block 20"},
    "Uni Hospital":           {"lat": 31.257986, "lng": 75.706851, "desc": "University Hospital, North Campus"},
    "Food Court LPU":         {"lat": 31.257737, "lng": 75.708295, "desc": "Central Food Court, Uni-Mall area, North Campus"},
    "NK Food Court":          {"lat": 31.246922, "lng": 75.704529, "desc": "NK Food Court, South Campus near Block 53"},
    "Central Mess":           {"lat": 31.252300, "lng": 75.700977, "desc": "Central Mess hall, south-west campus"},
    "Girls Hostel":           {"lat": 31.251466, "lng": 75.702678, "desc": "Girls Hostel Zone (GH-1 to GH-6)"},
    "Robo Park":              {"lat": 31.253455, "lng": 75.702871, "desc": "Robotics park near Helipad"},
    "Helipad":                {"lat": 31.254267, "lng": 75.702957, "desc": "LPU Helipad, central campus"},
    "Basketball Court":       {"lat": 31.248518, "lng": 75.701820, "desc": "Basketball court, south campus sports area"},
    "Cricket Ground":         {"lat": 31.247574, "lng": 75.700307, "desc": "Cricket ground, far-south campus"},
    "Football Ground":        {"lat": 31.251360, "lng": 75.699046, "desc": "Football ground, south-west campus"},
    "Innovation Studio":      {"lat": 31.251071, "lng": 75.705768, "desc": "Innovation Studio, east-south campus"},
    "Student Welfare":        {"lat": 31.255180, "lng": 75.705988, "desc": "Division of Student Welfare, near Block 13"},
    "Mittal School of Business": {"lat": 31.254667, "lng": 75.705628, "desc": "MSB – Mittal School of Business, near Block 14"},
}

# ---------------------------------------------------------------------------
# Campus food outlets — used by the AI chat to answer food/stall queries
# ---------------------------------------------------------------------------

FOOD_OUTLETS = [
    {
        "name": "Central Food Court",
        "location": "Uni-Mall Area, North Campus",
        "block": "Food Court LPU",
        "type": "Food Court",
        "hours": "8 AM – 10 PM",
        "menu": ["Paneer Butter Masala Thali", "Chicken Biryani", "Veg Biryani",
                 "Masala Dosa", "Cheese Pizza", "Chicken Pizza", "Veg Burger",
                 "Aloo Paratha", "Chai"],
    },
    {
        "name": "NK Food Court",
        "location": "South Campus, Near Block 53",
        "block": "NK Food Court",
        "type": "Food Court",
        "hours": "9 AM – 9 PM",
        "menu": ["Egg Biryani", "Mutton Biryani", "Butter Chicken", "Chicken Momos",
                 "Veg Momos", "Chole Bhature", "Chicken Burger", "Cold Coffee"],
    },
    {
        "name": "Central Mess",
        "location": "South-West Campus",
        "block": "Central Mess",
        "type": "Hostel Mess",
        "hours": "7 AM – 9 PM (Meal slots)",
        "menu": ["Dal Makhani Thali", "Mix Veg", "Egg Curry", "Chicken Curry",
                 "Chapati / Rice", "Chai"],
    },
    {
        "name": "Uni-Mall Café Zone",
        "location": "Uni-Mall Ground Floor, North Campus",
        "block": "Food Court LPU",
        "type": "Café & Fast Food",
        "hours": "8 AM – 11 PM",
        "menu": ["Espresso", "Cappuccino", "Masala Chai", "Cold Coffee",
                 "Chocolate Shake", "Sandwiches", "French Fries", "Ice Cream Sundae"],
    },
    {
        "name": "Spice Garden",
        "location": "Block 32 Canteen, Central Academic Zone",
        "block": "Block 32",
        "type": "Canteen",
        "hours": "8 AM – 5 PM (Weekdays)",
        "menu": ["Rajma Chawal", "Sambar Dosa", "Poha", "Upma", "Veg Thali",
                 "Chai & Biscuits", "Bread Omelette"],
    },
    {
        "name": "Hunger Hub",
        "location": "Block 13 (Library Block) Basement",
        "block": "Block 13",
        "type": "Canteen",
        "hours": "9 AM – 6 PM",
        "menu": ["Veg Sandwich", "Club Sandwich", "Veg Pasta", "Chicken Pasta",
                 "Maggi Noodles", "Aloo Tikki Burger", "Lemon Iced Tea"],
    },
    {
        "name": "Pizza Point",
        "location": "Uni-Mall, Level 1",
        "block": "Food Court LPU",
        "type": "Pizza & Fast Food",
        "hours": "10 AM – 10 PM",
        "menu": ["Margherita Pizza", "BBQ Chicken Pizza", "Farm Fresh Veg Pizza",
                 "Pasta Arrabiata", "Garlic Bread", "Burger", "Mojito"],
    },
    {
        "name": "Biryani Bowl",
        "location": "Block 25 Canteen, Lecture Zone",
        "block": "Block 25",
        "type": "Canteen",
        "hours": "11 AM – 4 PM",
        "menu": ["Chicken Biryani", "Veg Biryani", "Mutton Biryani", "Raita",
                 "Shorba (Soup)", "Gulab Jamun"],
    },
    {
        "name": "Snack Attack",
        "location": "Block 34 Ground Floor, Engineering Zone",
        "block": "Block 34",
        "type": "Snack Bar",
        "hours": "8 AM – 6 PM",
        "menu": ["Veg Momos", "Chicken Momos", "Pav Bhaji", "Chole Kulche",
                 "Dahi Puri", "Chai", "Sugarcane Juice"],
    },
    {
        "name": "Chill Zone Ice Cream",
        "location": "Main Gate, Entrance Plaza",
        "block": "Main Gate",
        "type": "Dessert Shop",
        "hours": "10 AM – 11 PM",
        "menu": ["Softy Ice Cream", "Kulfi", "Ice Cream Sandwich",
                 "Chocolate Bar", "Mango Ice Cream"],
    },
    {
        "name": "Hostel Mess (BH)",
        "location": "Boys Hostel Zone, South Campus",
        "block": "Block 57",
        "type": "Hostel Mess",
        "hours": "7 AM – 9 PM (Meal slots)",
        "menu": ["Dal Makhani Thali", "Mix Veg Sabzi", "Egg Curry",
                 "Chicken Curry Thali", "Chapati / Rice", "Chai"],
    },
]
