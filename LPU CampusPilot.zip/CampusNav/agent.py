"""
Groq-powered agent loop with tool calling.

Keeps a per-session conversation history and iterates
model -> tool calls -> tool results -> model until the model produces a
final text answer (bounded by MAX_TOOL_ROUNDS).
"""

import os
from datetime import datetime

from groq import Groq

from tools import TOOL_SCHEMAS, execute_tool

GROQ_MODEL = os.environ.get("GROQ_MODEL", "llama-3.3-70b-versatile")
MAX_TOOL_ROUNDS = 6
MAX_HISTORY_MESSAGES = 40

_client = None


def get_client() -> Groq:
    global _client
    if _client is None:
        api_key = os.environ.get("GROQ_API_KEY", "").strip()
        if not api_key:
            raise RuntimeError(
                "GROQ_API_KEY is not set. Copy .env.example to .env and add your key "
                "from https://console.groq.com/keys"
            )
        _client = Groq(api_key=api_key)
    return _client


SYSTEM_PROMPT = """You are CampusPilot, the Smart Campus Navigation & Event Logistics Agent for \
Lovely Professional University (LPU), main campus on the Jalandhar-Delhi G.T. Road, Phagwara, Punjab. \
You assist Verto {name} ({reg_no}, {programme}). LPU students are called "Vertos"; timetable and \
room-change announcements come through UMS (LPU's University Management System), which you monitor live.

Your capabilities — use the right tool for each:
1. **Timetable**: get_student_schedule — today's classes, times, rooms, and LIVE UMS room changes/postponements.
2. **Building/Block lookup**: find_building — "where is Block 32?", "where is the library?", "where is the hospital?" etc. \
   You know ALL 60+ campus blocks, hostels, sports grounds, and landmarks with GPS coordinates.
3. **Food outlets**: find_food_outlet — "where can I get pizza?", "where is Spice Garden?", "what food stalls are there?" etc. \
   You know every canteen, food court, café, and mess on campus with menus and hours.
4. **Navigation**: find_route — optimal walking routes between any two campus locations with crowd warnings.
5. **Events**: get_campus_events + register_for_event — Spectra 2026 and One World 2026 fest events, seats, registration.
6. **Alerts**: get_recent_notifications — room changes, postponements, crowd surges, venue changes.
7. **Crowd**: get_crowd_levels — live crowd density at every location.
8. **Locations**: list_locations — all mapped campus locations.

Rules:
- ALWAYS use your tools for facts. Never invent rooms, times, routes, or food outlets.
- If the user asks about a building, block, hostel, or landmark → use find_building.
- If the user asks about food, eating, canteen, stall, or café → use find_food_outlet.
- If the user asks about timetable, schedule, or class changes → use get_student_schedule.
- If the user asks about what changed, disruptions, or room moves → use get_recent_notifications AND get_student_schedule.
- If the user asks about events or fests → use get_campus_events.
- When registering for a full event, say so and suggest an alternative with seats left.
- Be concise and practical: bullet points, times, and walking minutes. Friendly tone; \
you may address the student as a fellow Verto.
- Current date: {date}. All times are 24-hour local campus time."""


def build_system_prompt() -> str:
    import campus_data as cd
    return SYSTEM_PROMPT.format(
        name=cd.STUDENT["name"], reg_no=cd.STUDENT["reg_no"],
        programme=cd.STUDENT["programme"], date=datetime.now().strftime("%A, %d %B %Y"),
    )


# session_id -> list of message dicts (excluding the system prompt)
_sessions: dict[str, list] = {}


def _trim(history: list) -> list:
    """Bound history size without splitting an assistant/tool-call group."""
    if len(history) <= MAX_HISTORY_MESSAGES:
        return history
    trimmed = history[-MAX_HISTORY_MESSAGES:]
    # never start on a dangling tool result
    while trimmed and trimmed[0]["role"] == "tool":
        trimmed.pop(0)
    return trimmed


def chat(session_id: str, user_message: str) -> dict:
    """Run one agent turn. Returns {'reply': str, 'tool_trace': [str, ...]}."""
    client = get_client()
    history = _sessions.setdefault(session_id, [])
    history.append({"role": "user", "content": user_message})

    tool_trace = []
    for _ in range(MAX_TOOL_ROUNDS):
        messages = [{"role": "system", "content": build_system_prompt()}] + _trim(history)
        response = client.chat.completions.create(
            model=GROQ_MODEL,
            messages=messages,
            tools=TOOL_SCHEMAS,
            tool_choice="auto",
            temperature=0.4,
            max_tokens=1024,
        )
        msg = response.choices[0].message

        if not msg.tool_calls:
            reply = msg.content or "(no response)"
            history.append({"role": "assistant", "content": reply})
            _sessions[session_id] = _trim(history)
            return {"reply": reply, "tool_trace": tool_trace}

        # record the assistant tool-call turn, then execute each tool
        history.append({
            "role": "assistant",
            "content": msg.content or "",
            "tool_calls": [{
                "id": tc.id, "type": "function",
                "function": {"name": tc.function.name, "arguments": tc.function.arguments},
            } for tc in msg.tool_calls],
        })
        for tc in msg.tool_calls:
            result = execute_tool(tc.function.name, tc.function.arguments)
            tool_trace.append(tc.function.name)
            history.append({"role": "tool", "tool_call_id": tc.id, "content": result})

    # tool-round budget exhausted: force a final plain answer
    messages = [{"role": "system", "content": build_system_prompt()}] + _trim(history) + [
        {"role": "user", "content": "Summarise your findings for the student now, without calling more tools."}
    ]
    response = client.chat.completions.create(
        model=GROQ_MODEL, messages=messages, temperature=0.4, max_tokens=1024,
    )
    reply = response.choices[0].message.content or "(no response)"
    history.append({"role": "assistant", "content": reply})
    _sessions[session_id] = _trim(history)
    return {"reply": reply, "tool_trace": tool_trace}


def reset_session(session_id: str):
    _sessions.pop(session_id, None)
