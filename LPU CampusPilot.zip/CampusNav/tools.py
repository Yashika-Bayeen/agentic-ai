"""
Tool implementations + JSON schemas exposed to the Groq agent.

Every tool returns a plain dict (JSON-serialisable) so results can be fed
straight back into the model as tool messages.
"""

import heapq
import json
from datetime import datetime

import campus_data as cd


# ---------------------------------------------------------------------------
# Core algorithms
# ---------------------------------------------------------------------------

def dijkstra(origin: str, destination: str):
    """Shortest walking route between two campus locations."""
    if origin not in cd.GRAPH or destination not in cd.GRAPH:
        return None, 0
    dist = {origin: 0}
    prev = {}
    pq = [(0, origin)]
    while pq:
        d, node = heapq.heappop(pq)
        if node == destination:
            break
        if d > dist.get(node, float("inf")):
            continue
        for nxt, w in cd.GRAPH[node]:
            nd = d + w
            if nd < dist.get(nxt, float("inf")):
                dist[nxt] = nd
                prev[nxt] = node
                heapq.heappush(pq, (nd, nxt))
    if destination not in dist:
        return None, 0
    path = [destination]
    while path[-1] != origin:
        path.append(prev[path[-1]])
    path.reverse()
    return path, dist[destination]


def resolve_location(query: str):
    """Map a free-text location reference to a location id."""
    if not query:
        return None
    q = query.strip().lower().replace("-", " ").replace("_", " ")
    for loc_id in cd.LOCATIONS:
        if q == loc_id.replace("_", " "):
            return loc_id
    for loc_id, info in cd.LOCATIONS.items():
        if q in info["name"].lower():
            return loc_id
    # loose match on individual words ("library", "food", "block 32", ...)
    for loc_id, info in cd.LOCATIONS.items():
        name = info["name"].lower()
        if all(word in name for word in q.split()):
            return loc_id
    return None


# ---------------------------------------------------------------------------
# Tool functions (called by the agent)
# ---------------------------------------------------------------------------

def get_student_schedule() -> dict:
    with cd.STATE_LOCK:
        now = datetime.now().strftime("%H:%M")
        classes = []
        for c in cd.SCHEDULE:
            classes.append({
                **{k: c[k] for k in ("id", "time", "end", "course", "room", "status")},
                "location": c["location"],
                "location_name": cd.location_name(c["location"]),
            })
        return {"student": cd.STUDENT, "current_time": now, "classes": classes}


def find_route(origin: str, destination: str) -> dict:
    o = resolve_location(origin)
    d = resolve_location(destination)
    if not o:
        return {"error": f"Unknown origin '{origin}'. Use list_locations to see valid places."}
    if not d:
        return {"error": f"Unknown destination '{destination}'. Use list_locations to see valid places."}
    path, minutes = dijkstra(o, d)
    if path is None:
        return {"error": "No route found."}
    with cd.STATE_LOCK:
        cd.LAST_ROUTE["path"] = path
        cd.LAST_ROUTE["minutes"] = minutes
        crowded = [cd.location_name(p) for p in path if cd.CROWD.get(p, 0) >= 75]
    edge_minutes = {}
    for x, y, w in cd.EDGES:
        edge_minutes[(x, y)] = edge_minutes[(y, x)] = w
    legs = [{"from": cd.location_name(a), "to": cd.location_name(b),
             "minutes": edge_minutes[(a, b)]}
            for a, b in zip(path, path[1:])]
    return {
        "origin": cd.location_name(o),
        "destination": cd.location_name(d),
        "total_walking_minutes": minutes,
        "legs": legs,
        "crowd_warnings": crowded or "none",
    }


def get_campus_events() -> dict:
    with cd.STATE_LOCK:
        return {"fests": "LPU Spectra 2026 & One World 2026", "events": [
            {**{k: e[k] for k in ("id", "name", "fest", "time", "capacity", "registered", "student_registered")},
             "venue": cd.location_name(e["venue"]),
             "seats_left": e["capacity"] - e["registered"]}
            for e in cd.EVENTS
        ]}


def register_for_event(event_id: str) -> dict:
    with cd.STATE_LOCK:
        for e in cd.EVENTS:
            if e["id"].lower() == event_id.strip().lower():
                if e["student_registered"]:
                    return {"status": "already_registered", "event": e["name"]}
                if e["registered"] >= e["capacity"]:
                    return {"status": "full", "event": e["name"],
                            "hint": "Suggest a similar event with seats left."}
                e["registered"] += 1
                e["student_registered"] = True
                cd.add_notification("event", "Registration confirmed",
                                    f"You are registered for {e['name']} ({e['fest']}) at "
                                    f"{cd.location_name(e['venue'])}, {e['time']}.")
                return {"status": "registered", "event": e["name"],
                        "venue": cd.location_name(e["venue"]), "time": e["time"]}
        return {"error": f"No event with id '{event_id}'. Use get_campus_events first."}


def get_crowd_levels() -> dict:
    with cd.STATE_LOCK:
        levels = [{"location": cd.location_name(k), "crowd_percent": v,
                   "level": "high" if v >= 75 else "moderate" if v >= 45 else "low"}
                  for k, v in cd.CROWD.items()]
    levels.sort(key=lambda x: -x["crowd_percent"])
    return {"crowd_levels": levels}


def get_recent_notifications(limit: int = 5) -> dict:
    with cd.STATE_LOCK:
        return {"notifications": cd.NOTIFICATIONS[:max(1, min(int(limit or 5), 20))]}


def list_locations() -> dict:
    return {"locations": [{"id": k, "name": v["name"]} for k, v in cd.LOCATIONS.items()]}


def find_building(query: str) -> dict:
    """Search for a campus building/block by name or keyword."""
    if not query:
        return {"error": "Please provide a building name or keyword to search."}
    q = query.strip().lower()
    results = []
    for name, info in cd.BUILDINGS.items():
        if q in name.lower() or q in info["desc"].lower():
            results.append({
                "name": name,
                "description": info["desc"],
                "gps": f"{info['lat']:.6f}°N, {info['lng']:.6f}°E",
            })
    if not results:
        # Try loose word matching
        words = q.split()
        for name, info in cd.BUILDINGS.items():
            combined = (name + " " + info["desc"]).lower()
            if all(w in combined for w in words):
                results.append({
                    "name": name,
                    "description": info["desc"],
                    "gps": f"{info['lat']:.6f}°N, {info['lng']:.6f}°E",
                })
    if not results:
        return {"message": f"No building found matching '{query}'. Try 'Block 32', 'library', 'hostel', 'food court', etc."}
    return {"buildings": results[:10]}


def find_food_outlet(query: str = "") -> dict:
    """Search for campus food outlets by name, food item, or cuisine type."""
    q = (query or "").strip().lower()
    results = []
    for outlet in cd.FOOD_OUTLETS:
        if not q:
            # Return all outlets
            results.append({
                "name": outlet["name"],
                "location": outlet["location"],
                "type": outlet["type"],
                "hours": outlet["hours"],
                "menu_highlights": outlet["menu"][:5],
            })
            continue
        # Match by name, type, location, or menu items
        name_match = q in outlet["name"].lower() or q in outlet["type"].lower() or q in outlet["location"].lower()
        menu_match = any(q in item.lower() for item in outlet["menu"])
        if name_match or menu_match:
            matched_items = [item for item in outlet["menu"] if q in item.lower()] if menu_match else []
            results.append({
                "name": outlet["name"],
                "location": outlet["location"],
                "type": outlet["type"],
                "hours": outlet["hours"],
                "matched_items": matched_items or outlet["menu"][:4],
                "full_menu": outlet["menu"],
            })
    if not results and q:
        return {"message": f"No food outlets found for '{query}'. Try 'pizza', 'biryani', 'momos', 'chai', 'coffee', etc."}
    return {"outlets": results}


# ---------------------------------------------------------------------------
# Registry + JSON schemas for Groq tool calling
# ---------------------------------------------------------------------------

TOOL_FUNCTIONS = {
    "get_student_schedule": get_student_schedule,
    "find_route": find_route,
    "get_campus_events": get_campus_events,
    "register_for_event": register_for_event,
    "get_crowd_levels": get_crowd_levels,
    "get_recent_notifications": get_recent_notifications,
    "list_locations": list_locations,
    "find_building": find_building,
    "find_food_outlet": find_food_outlet,
}

TOOL_SCHEMAS = [
    {"type": "function", "function": {
        "name": "get_student_schedule",
        "description": "Get the student's profile and today's full class timetable, including any live room changes or postponements, plus the current time.",
        "parameters": {"type": "object", "properties": {}, "required": []},
    }},
    {"type": "function", "function": {
        "name": "find_route",
        "description": "Compute the fastest walking route between two campus locations (Dijkstra over the campus map). Accepts free-text names like 'library', 'block 32', 'food court'. Also flags crowded points on the route.",
        "parameters": {"type": "object", "properties": {
            "origin": {"type": "string", "description": "Starting location, e.g. 'Block 32' or 'main gate'"},
            "destination": {"type": "string", "description": "Target location, e.g. 'library' or 'Unipolis'"},
        }, "required": ["origin", "destination"]},
    }},
    {"type": "function", "function": {
        "name": "get_campus_events",
        "description": "List all LPU fest events (Spectra 2026 and One World 2026) with fest name, venue, time, capacity, seats left, and whether the student is registered.",
        "parameters": {"type": "object", "properties": {}, "required": []},
    }},
    {"type": "function", "function": {
        "name": "register_for_event",
        "description": "Register the student for a fest event by its event id (e.g. 'E3'). Call get_campus_events first to find the id.",
        "parameters": {"type": "object", "properties": {
            "event_id": {"type": "string", "description": "Event id such as E1, E2..."},
        }, "required": ["event_id"]},
    }},
    {"type": "function", "function": {
        "name": "get_crowd_levels",
        "description": "Get live crowd density (percent) for every campus location, sorted busiest first. Use to avoid congested areas or answer 'how busy is X'.",
        "parameters": {"type": "object", "properties": {}, "required": []},
    }},
    {"type": "function", "function": {
        "name": "get_recent_notifications",
        "description": "Get the most recent campus alerts: room changes, postponements, crowd surges, venue changes.",
        "parameters": {"type": "object", "properties": {
            "limit": {"type": "integer", "description": "How many alerts to fetch (default 5, max 20)"},
        }, "required": []},
    }},
    {"type": "function", "function": {
        "name": "list_locations",
        "description": "List every mapped campus location with its id and full name.",
        "parameters": {"type": "object", "properties": {}, "required": []},
    }},
    {"type": "function", "function": {
        "name": "find_building",
        "description": "Search for any campus building, block, hostel, sports ground, or landmark by name or keyword. Returns GPS coordinates and description. Use this when a student asks 'where is Block X?', 'where is the library?', 'where is the hospital?', etc.",
        "parameters": {"type": "object", "properties": {
            "query": {"type": "string", "description": "Building name or keyword, e.g. 'Block 32', 'library', 'hostel', 'food court', 'hospital'"},
        }, "required": ["query"]},
    }},
    {"type": "function", "function": {
        "name": "find_food_outlet",
        "description": "Search for campus food outlets, stalls, canteens, or cafes by name or food item. Returns outlet name, location, hours, and menu. Use this when a student asks 'where can I get pizza?', 'where is Spice Garden?', 'what food is available?', etc.",
        "parameters": {"type": "object", "properties": {
            "query": {"type": "string", "description": "Food item or outlet name, e.g. 'pizza', 'biryani', 'momos', 'Spice Garden', 'coffee'. Leave empty to list all outlets."},
        }, "required": []},
    }},
]


def execute_tool(name: str, arguments_json: str) -> str:
    """Run a tool by name with JSON-encoded arguments; always returns a JSON string."""
    fn = TOOL_FUNCTIONS.get(name)
    if fn is None:
        return json.dumps({"error": f"Unknown tool '{name}'"})
    try:
        args = json.loads(arguments_json) if arguments_json else {}
        if not isinstance(args, dict):
            args = {}
        return json.dumps(fn(**args))
    except TypeError as e:
        return json.dumps({"error": f"Bad arguments for {name}: {e}"})
    except Exception as e:  # tool errors must never crash the agent loop
        return json.dumps({"error": f"{type(e).__name__}: {e}"})
