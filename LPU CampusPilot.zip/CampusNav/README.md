# 🧭 LPU CampusPilot — Smart Campus Navigation & Event Logistics Agent

A real-time **agentic campus concierge** for Lovely Professional University's main campus
(Jalandhar-Delhi G.T. Road, Phagwara), powered by **Groq** (Llama 3.3 70B with tool calling).
It watches UMS-style announcements for a Verto's timetable, detects live disruptions
(room changes, postponements, crowd surges, fest venue shifts), **notifies the student, and
replans their optimal route across campus blocks** — automatically.

The campus graph covers 16 real LPU landmarks: Gate 1, Uni-Mall, Block 13 Central Library,
Blocks 25-27 lecture theatres, Block 32 (School of CSE), Blocks 55-57, Baldev Raj Mittal
Unipolis, Shanti Devi Mittal Auditorium, Uni-Hospital, the food court, sports stadium and
both hostel zones.

## What it does

| Friction | Agentic solution |
|---|---|
| Class room/block changes mid-day | Simulator injects a UMS-style change → instant alert **with the new fastest route already computed** |
| Lectures get postponed | Schedule updates live; agent suggests what to do with the free window |
| Huge ~600-acre campus, dozens of blocks | Dijkstra route planner with exact leg-by-leg walking minutes and crowd-aware warnings |
| Fest chaos (Spectra & One World 2026) | Browse both fests' events, live seat counts, one-message registration, venue-change alerts |
| Crowds during fests | Live crowd sensors (simulated) shown on the map; agent flags congested points on your route |

## Architecture

```
static/index.html   ← dashboard: chat + live schedule + alerts + SVG campus map + events
        │  (polls /api/state every 4 s, chats via /api/chat)
main.py             ← FastAPI server
agent.py            ← Groq agent loop (tool calling, per-session memory)
tools.py            ← 7 agent tools + Dijkstra router + fuzzy location resolver
simulator.py        ← background thread injecting realistic campus disruptions
campus_data.py      ← campus graph, timetable, Spectra events, crowd state (thread-safe)
```

**Agent tools:** `get_student_schedule`, `find_route`, `get_campus_events`,
`register_for_event`, `get_crowd_levels`, `get_recent_notifications`, `list_locations`.

The agent loop sends the conversation + tool schemas to Groq, executes whatever tools the
model requests, feeds results back, and repeats until the model answers (max 6 rounds).
Disruption notifications are replanned **deterministically** (same Dijkstra the agent uses),
so alerts work even with zero LLM calls in the background.

## Setup & run

```powershell
# 1. Install dependencies
pip install -r requirements.txt

# 2. Add your Groq API key (free at https://console.groq.com/keys)
copy .env.example .env
# then edit .env and paste your key

# 3. Start the server
python -m uvicorn main:app

# 4. Open http://127.0.0.1:8000
```

## Try these prompts

- *"What's my day looking like? Anything changed?"*
- *"Fastest route from the library to Block 34, avoiding crowds?"*
- *"My OS lab moved — where do I go now and how long will it take from my current class?"*
- *"Which Spectra events still have seats? Register me for the hackathon."*
- *"A class got postponed — replan my afternoon around it."*

Wait ~30–60 s and disruptions start appearing in the **Live Campus Alerts** panel; the
schedule card and map update in real time.

## Notes

- Campus layout, timetable and events are illustrative demo data; swap `campus_data.py`
  for real university APIs (timetable service, occupancy sensors, fest registration) to go live.
- Model is configurable via `GROQ_MODEL` in `.env` (any Groq model with tool-use support).
